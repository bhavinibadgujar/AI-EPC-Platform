from backend.agents.knowledge.loader import PDFLoader

loader = PDFLoader(
    chunk_size=800,
    chunk_overlap=150
)

chunks = loader.load("scripts/output/pdfs/spec_1.pdf")

print("=" * 60)
print("Total Chunks:", len(chunks))
print("=" * 60)

for i, chunk in enumerate(chunks):
    print(f"\nChunk {i+1}")
    print(f"Length: {len(chunk.page_content)}")
    print(chunk.page_content[:200])