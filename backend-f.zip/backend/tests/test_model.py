from google import genai
from backend.config import GEMINI_API_KEY

client = genai.Client(api_key=GEMINI_API_KEY)

print("Available Embedding Models:\n")

for model in client.models.list():
    if "embedding" in model.name.lower():
        print(model.name)