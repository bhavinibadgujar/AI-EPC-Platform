from backend.agents.knowledge.loader import PDFLoader
from backend.agents.knowledge.embeddings import EmbeddingManager

loader = PDFLoader()

chunks = loader.load("scripts/output/pdfs/spec_1.pdf")

manager = EmbeddingManager()

db = manager.create_vector_store(chunks)

print("Database created successfully!")

print("Chunks stored:", len(chunks))