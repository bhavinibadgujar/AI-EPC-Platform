from backend.config import GEMINI_API_KEY
from google import genai


def test_gemini():
    client = genai.Client(api_key=GEMINI_API_KEY)

    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents="Say Hello from Gemini!"
    )

    print("\nResponse:")
    print(response.text)


if __name__ == "__main__":
    test_gemini()