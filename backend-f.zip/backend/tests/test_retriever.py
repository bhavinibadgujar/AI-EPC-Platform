from backend.agents.knowledge.retriever import KnowledgeRetriever

retriever = KnowledgeRetriever()

retriever.print_results(
    "What is the cooling redundancy?"
)