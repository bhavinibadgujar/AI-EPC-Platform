from backend.agents.knowledge.agent import KnowledgeAgent

agent = KnowledgeAgent()

question = input("Question: ")

answer = agent.ask(question)

print("\nAnswer:\n")
print(answer)
