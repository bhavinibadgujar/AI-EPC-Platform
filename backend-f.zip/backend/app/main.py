﻿"""Archived compatibility entry point.

Run the demo backend with:
    uvicorn backend.main:app --reload
"""

from backend.main import app
