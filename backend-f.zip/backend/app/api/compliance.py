from fastapi import APIRouter, HTTPException
from app.ai.agents.compliance.agent import ComplianceAgent
from app.ai.agents.consequence.engine import ConsequenceEngine
from app.schemas.compliance import ComplianceCheckRequest, ComplianceCheckResponse
from app.services.document_service import get_document_text  # Brinda's service
from app.db.session import get_db  # adjust to your actual db session helper
from app.db.models import ComplianceFlagRecord, ConsequenceRecord  # adjust to your models

router = APIRouter(prefix="/api/compliance", tags=["Compliance"])
agent = ComplianceAgent()
consequence_engine = ConsequenceEngine()

@router.post("/check", response_model=ComplianceCheckResponse)
async def check_compliance(request: ComplianceCheckRequest):
    spec_text = get_document_text(request.spec_document_id)
    submittal_text = get_document_text(request.submittal_document_id)

    if not spec_text or not submittal_text:
        raise HTTPException(status_code=404, detail="One or both documents not found")

    result = agent.check(spec_text, submittal_text)

    # Persist flags + auto-run consequence engine on each flag
    db = next(get_db())
    for flag in result["flags"]:
        flag_record = ComplianceFlagRecord(
            spec_document_id=request.spec_document_id,
            submittal_document_id=request.submittal_document_id,
            **flag
        )
        db.add(flag_record)
        db.flush()  # get flag_record.id before commit

        consequence = consequence_engine.calculate(flag)
        db.add(ConsequenceRecord(compliance_flag_id=flag_record.id, **consequence))

    db.commit()
    return result